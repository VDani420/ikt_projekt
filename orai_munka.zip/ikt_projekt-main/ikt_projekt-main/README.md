# ikt_projekt
 
## Képek és ikonok forrása

- pexels:https://www.pexels.com/hu-hu/
- pixabay:https://pixabay.com/hu/
- picsum:https://picsum.photos/images
- freepik:https://www.freepik.com/
- flaticon:https://www.flaticon.com/